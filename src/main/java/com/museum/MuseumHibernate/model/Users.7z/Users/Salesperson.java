package com.museum.MuseumHibernate.model.Users;

public class Salesperson extends EmployeeDecorator{
	
	public Salesperson() {}
	
	public Salesperson(Worker specializedEmployee) {
		super(specializedEmployee);
	}
}
